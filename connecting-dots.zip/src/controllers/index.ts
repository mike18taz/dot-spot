export * from './ping.controller';
export * from './dot.controller';
